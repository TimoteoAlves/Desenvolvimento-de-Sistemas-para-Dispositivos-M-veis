import 'package:app_anuncios/ad.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();

  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('ads.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    const idType = 'INTEGER PRIMARY KEY AUTOINCREMENT';
    const textType = 'TEXT NOT NULL';
    const doubleType = 'REAL NOT NULL';

    await db.execute('''
    CREATE TABLE ads ( 
      id $idType, 
      title $textType,
      description $textType,
      price $doubleType,
      imageUrl $textType,
      category $textType,
      location $textType
    )
    ''');
  }

  Future<void> insertAd(Ad ad) async {
    final db = await instance.database;
    await db.insert('ads', ad.toJson());
  }

  Future<List<Ad>> fetchAds() async {
    final db = await instance.database;
    final result = await db.query('ads');

    return result.map((json) => Ad.fromJson(json)).toList();
  }

  Future<int> updateAd(Ad ad) async {
    final db = await instance.database;

    return db.update(
      'ads',
      ad.toJson(),
      where: 'id = ?',
      whereArgs: [ad.id],
    );
  }

  Future<int> deleteAd(int id) async {
    final db = await instance.database;

    return await db.delete(
      'ads',
      where: 'id = ?',
      whereArgs: [id],
    );
  }
}
