import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'ad.dart';
import 'database_helper.dart';

class AddEditAdScreen extends StatefulWidget {
  final Ad? ad;

  const AddEditAdScreen({super.key, this.ad});

  @override
  _AddEditAdScreenState createState() => _AddEditAdScreenState();
}

class _AddEditAdScreenState extends State<AddEditAdScreen> {
  final _formKey = GlobalKey<FormState>();
  bool _includeImage = false;
  late TextEditingController _titleController;
  late TextEditingController _descriptionController;
  late TextEditingController _priceController;
  late TextEditingController _categoryController;
  late TextEditingController _locationController;
  final ImagePicker _picker = ImagePicker();
  XFile? _imageFile;
  String? _existingImagePath;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.ad?.title ?? '');
    _descriptionController =
        TextEditingController(text: widget.ad?.description ?? '');
    _priceController =
        TextEditingController(text: widget.ad?.price.toString() ?? '');
    _categoryController =
        TextEditingController(text: widget.ad?.category ?? '');
    _locationController =
        TextEditingController(text: widget.ad?.location ?? '');
    _existingImagePath = widget.ad?.imageUrl;
    _includeImage =
        _existingImagePath != null && _existingImagePath!.isNotEmpty;
  }

  Future<void> _pickImage(ImageSource source) async {
    final pickedFile = await _picker.pickImage(source: source);
    if (pickedFile != null) {
      setState(() {
        _imageFile = pickedFile;
        _existingImagePath = null;
      });
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _priceController.dispose();
    _categoryController.dispose();
    _locationController.dispose();
    super.dispose();
  }

  void _saveAd() async {
    if (_formKey.currentState!.validate()) {
      final newAd = Ad(
        title: _titleController.text,
        description: _descriptionController.text,
        price: double.parse(_priceController.text),
        imageUrl: _imageFile?.path ?? _existingImagePath ?? '',
        category: _categoryController.text,
        location: _locationController.text,
      );

      if (widget.ad == null) {
        await DatabaseHelper.instance.insertAd(newAd);
      } else {
        newAd.id = widget.ad!.id;
        await DatabaseHelper.instance.updateAd(newAd);
      }

      Navigator.of(context).pop(newAd);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.ad == null ? 'Novo Anúncio' : 'Editar Anúncio'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextFormField(
                controller: _titleController,
                decoration: InputDecoration(
                  labelText: 'Título',
                  labelStyle: TextStyle(color: Colors.black),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.yellow),
                  ),
                ),
                validator: (value) => value == null || value.isEmpty
                    ? 'Por favor, insira um título'
                    : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _descriptionController,
                decoration: InputDecoration(
                  labelText: 'Descrição',
                  labelStyle: TextStyle(color: Colors.black),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.yellow),
                  ),
                ),
                maxLines: 3,
                validator: (value) => value == null || value.isEmpty
                    ? 'Por favor, insira uma descrição'
                    : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _priceController,
                decoration: InputDecoration(
                  labelText: 'Preço',
                  labelStyle: TextStyle(color: Colors.black),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.yellow),
                  ),
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Insira um preço válido';
                  }
                  try {
                    final price = double.parse(value);
                    if (price <= 0) {
                      return 'O preço deve ser maior que zero';
                    }
                  } catch (e) {
                    return 'Por favor, insira um número válido';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _locationController.text.isEmpty
                    ? null
                    : _locationController.text,
                decoration: InputDecoration(
                  labelText: 'Localização',
                  labelStyle: TextStyle(color: Colors.black),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.yellow),
                  ),
                ),
                items: [
                  'Acre',
                  'Alagoas',
                  'Amapá',
                  'Amazonas',
                  'Bahia',
                  'Ceará',
                  'Distrito Federal',
                  'Espírito Santo',
                  'Goiás',
                  'Maranhão',
                  'Mato Grosso',
                  'Mato Grosso do Sul',
                  'Minas Gerais',
                  'Pará',
                  'Paraíba',
                  'Paraná',
                  'Pernambuco',
                  'Piauí',
                  'Rio de Janeiro',
                  'Rio Grande do Norte',
                  'Rio Grande do Sul',
                  'Rondônia',
                  'Roraima',
                  'Santa Catarina',
                  'São Paulo',
                  'Sergipe',
                  'Tocantins'
                ].map((String state) {
                  return DropdownMenuItem<String>(
                    value: state,
                    child: Text(state, style: TextStyle(color: Colors.black)),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _locationController.text = value!;
                  });
                },
                validator: (value) =>
                    value == 'Selecione o Estado' || value == null
                        ? 'Por favor, selecione um estado'
                        : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _categoryController,
                decoration: InputDecoration(
                  labelText: 'Categoria',
                  labelStyle: TextStyle(color: Colors.black),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.yellow),
                  ),
                ),
                validator: (value) => value == null || value.isEmpty
                    ? 'Por favor, insira uma categoria'
                    : null,
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text("Incluir Imagem",
                      style: TextStyle(color: Colors.black)),
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.grey[300],
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Switch(
                      value: _includeImage,
                      onChanged: (value) {
                        setState(() {
                          _includeImage = value;
                          if (!value) _imageFile = null;
                        });
                      },
                      activeColor: Colors.yellow,
                      inactiveThumbColor: Colors.grey,
                      inactiveTrackColor: Colors.grey[400],
                    ),
                  ),
                ],
              ),
              if (_includeImage)
                Column(
                  children: [
                    ElevatedButton(
                      onPressed: () => _pickImage(ImageSource.camera),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.yellow[800],
                      ),
                      child: const Text('Tirar Foto',
                          style: TextStyle(color: Colors.black)),
                    ),
                    ElevatedButton(
                      onPressed: () => _pickImage(ImageSource.gallery),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.yellow[800],
                      ),
                      child: const Text('Escolher da Galeria',
                          style: TextStyle(color: Colors.black)),
                    ),
                    if (_imageFile != null || _existingImagePath != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 16.0),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Image.file(
                            File(_imageFile?.path ?? _existingImagePath!),
                            width: 100,
                            height: 100,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                  ],
                ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _saveAd,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.yellow[800],
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  textStyle: const TextStyle(fontSize: 18),
                ),
                child:
                    const Text('Salvar', style: TextStyle(color: Colors.black)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
