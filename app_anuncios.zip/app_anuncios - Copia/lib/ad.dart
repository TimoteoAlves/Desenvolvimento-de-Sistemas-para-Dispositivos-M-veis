class Ad {
  int? id;
  String title;
  String description;
  double price;
  String imageUrl;
  String category;
  String location;

  Ad({
    this.id,
    required this.title,
    required this.description,
    required this.price,
    required this.imageUrl,
    required this.category,
    required this.location,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'description': description,
        'price': price,
        'imageUrl': imageUrl,
        'category': category,
        'location': location,
      };

  static Ad fromJson(Map<String, dynamic> json) => Ad(
        id: json['id'],
        title: json['title'],
        description: json['description'],
        price: json['price'],
        imageUrl: json['imageUrl'],
        category: json['category'],
        location: json['location'],
      );
}
