import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:io';
import 'ad.dart';
import 'add_edit_ad_screen.dart';
import 'database_helper.dart';

class AdListScreen extends StatefulWidget {
  const AdListScreen({super.key});

  @override
  _AdListScreenState createState() => _AdListScreenState();
}

class _AdListScreenState extends State<AdListScreen> {
  List<Ad> _ads = [];

  @override
  void initState() {
    super.initState();
    _loadAds();
  }

  void _loadAds() async {
    final ads = await DatabaseHelper.instance.fetchAds();
    setState(() {
      _ads = ads;
    });
  }

  void _navigateToAddEditScreen({Ad? ad, int? index}) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddEditAdScreen(ad: ad),
      ),
    );

    if (result != null) {
      _loadAds();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Anúncio salvo com sucesso!')),
      );
    }
  }

  void _deleteAd(int index) async {
    await DatabaseHelper.instance.deleteAd(_ads[index].id!);
    _loadAds();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Anúncio excluído com sucesso!')),
    );
  }

  void _openShareOptions(Ad ad) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Wrap(
          children: <Widget>[
            ListTile(
              leading: const Icon(Icons.message),
              title: const Text('SMS'),
              onTap: () {
                Navigator.pop(context);
                _openSmsWithMessage(ad);
              },
            ),
            ListTile(
              leading: const Icon(Icons.share),
              title: const Text('Outros'),
              onTap: () {
                Navigator.pop(context);
                _shareAd(ad);
              },
            ),
          ],
        );
      },
    );
  }

  void _openSmsWithMessage(Ad ad) async {
    final String smsMessage = 'Confira este anúncio:\n'
        'Título: ${ad.title}\n'
        'Descrição: ${ad.description}\n'
        'Preço: R\$ ${ad.price.toStringAsFixed(2)}\n'
        'Localização: ${ad.location}';

    final Uri smsUri = Uri(
      scheme: 'sms',
      path: '',
      query: Uri(queryParameters: {'body': smsMessage}).query,
    );

    try {
      if (await canLaunch(smsUri.toString())) {
        await launch(smsUri.toString());
      } else {
        throw 'Não foi possível abrir o aplicativo de mensagens';
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao abrir o aplicativo de mensagens: $e')),
      );
    }
  }

  void _shareAd(Ad ad) {
    final String shareMessage = 'Confira este anúncio:\n'
        'Título: ${ad.title}\n'
        'Descrição: ${ad.description}\n'
        'Preço: R\$ ${ad.price.toStringAsFixed(2)}\n'
        'Localização: ${ad.location}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mercado Free',
            style: TextStyle(fontFamily: 'Georgia', color: Colors.black)),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: _ads.isEmpty
          ? const Center(
              child: Text('Nenhum anúncio!',
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 18,
                      fontWeight: FontWeight.w600)))
          : ListView.builder(
              itemCount: _ads.length,
              itemBuilder: (context, index) {
                final ad = _ads[index];
                return Card(
                  margin:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                  elevation: 6,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: InkWell(
                    onTap: () => _navigateToAddEditScreen(ad: ad, index: index),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              ad.imageUrl.isNotEmpty
                                  ? ClipRRect(
                                      borderRadius: BorderRadius.circular(10),
                                      child: Image.file(
                                        File(ad.imageUrl),
                                        width: 120,
                                        height: 120,
                                        fit: BoxFit.cover,
                                      ),
                                    )
                                  : const Icon(Icons.image_not_supported,
                                      size: 120, color: Colors.grey),
                              const SizedBox(width: 16),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      ad.title,
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black87,
                                          fontSize: 20),
                                    ),
                                    const SizedBox(height: 8),
                                    Text("Categoria: ${ad.category}",
                                        style: TextStyle(
                                            color: Colors.black54,
                                            fontSize: 16)),
                                    Text("Localização: ${ad.location}",
                                        style: TextStyle(
                                            color: Colors.black54,
                                            fontSize: 16)),
                                    const SizedBox(height: 8),
                                    Text(
                                      "R\$ ${ad.price.toStringAsFixed(2)}",
                                      style: TextStyle(
                                        fontSize: 18,
                                        color: Theme.of(context)
                                            .colorScheme
                                            .secondary,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(
                              height:
                                  16), // Espaçamento entre a imagem e a descrição
                          Text(
                            ad.description,
                            style:
                                TextStyle(color: Colors.black87, fontSize: 16),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.send,
                                    color: Colors.deepOrange),
                                onPressed: () => _openShareOptions(ad),
                              ),
                              IconButton(
                                icon:
                                    const Icon(Icons.delete, color: Colors.red),
                                onPressed: () => _deleteAd(index),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _navigateToAddEditScreen(),
        backgroundColor: Theme.of(context).primaryColor,
        child: const Icon(Icons.add),
      ),
    );
  }
}
