package com.timoteo.app_anuncios

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
